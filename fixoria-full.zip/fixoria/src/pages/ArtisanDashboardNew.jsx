import { useEffect, useState } from 'react';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Legend,
} from 'recharts';
import './ArtisanDashboardNew.css';

// Adjust this to match your actual API base URL
const API_BASE = 'http://localhost:8000';

const STATUS_LABELS = {
  pending: 'قيد الانتظار',
  accepted: 'مقبولة',
  in_progress: 'قيد التنفيذ',
  completed: 'مكتملة',
};

const PROGRESS_STEPS = [
  'تم الحجز',
  'في الطريق اليك',
  'يتم تنفيذ العملية',
  'تم تنفيذ العملية',
];

export default function ArtisanDashboardNew() {
  const [profile, setProfile] = useState(null);
  const [requests, setRequests] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [buildingTrend, setBuildingTrend] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    const headers = { Authorization: `Bearer ${token}` };

    Promise.all([
      fetch(`${API_BASE}/artisans/me`, { headers }).then((r) => r.json()),
      fetch(`${API_BASE}/requests`, { headers }).then((r) => r.json()).catch(() => []),
      fetch(`${API_BASE}/artisans/me/reviews`, { headers }).then((r) => r.json()).catch(() => []),
      fetch(`${API_BASE}/artisans/me/monthly-building-stats`, { headers }).then((r) => r.json()).catch(() => []),
    ])
      .then(([profileData, requestsData, reviewsData, trendData]) => {
        setProfile(profileData);
        setRequests(requestsData);
        setReviews(reviewsData);
        setBuildingTrend(trendData);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="dash-loading">جاري التحميل...</div>;
  if (error) return <div className="dash-error">حدث خطأ: {error}</div>;
  if (!profile) return null;

  const needsApproval = requests.filter((r) => r.status === 'pending');
  const inProgress = requests.filter((r) => ['accepted', 'in_progress'].includes(r.status));
  const completed = requests.filter((r) => r.status === 'completed');

  const avgRating =
    reviews.length > 0
      ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
      : profile.average_rating?.toFixed(1) ?? '—';

  const statCards = [
    { label: 'طلبات تحتاج موافقتك', value: needsApproval.length, icon: '🔔', accent: '#fee2e2' },
    { label: 'مواعيدك الحالية', value: inProgress.length, icon: '🛠️', accent: '#fef3c7' },
    { label: 'الطلبات المكتملة', value: completed.length, icon: '✅', accent: '#dcfce7' },
    { label: 'متوسط تقييمك', value: avgRating, icon: '⭐', accent: '#dbeafe' },
  ];

  return (
    <div className="dash-wrap" dir="rtl">
      <header className="dash-header">
        <div className="dash-header-row">
          <div>
            <p className="dash-greeting">أهلاً بيك 👋</p>
            <h1 className="dash-title">{profile.full_name || profile.name}</h1>
            <p className="dash-subtitle">
              {profile.verified ? '✅ حساب موثّق' : '⏳ بانتظار التوثيق من الإدارة'}
              {profile.service_type ? ` · ${profile.service_type}` : ''}
            </p>
          </div>
        </div>
      </header>

      {/* Stat Cards */}
      <section className="dash-stats-row">
        {statCards.map((card) => (
          <div className="dash-stat-card" key={card.label}>
            <div className="dash-stat-icon" style={{ background: card.accent }}>
              {card.icon}
            </div>
            <div>
              <p className="dash-stat-label">{card.label}</p>
              <p className="dash-stat-value">{card.value}</p>
            </div>
          </div>
        ))}
      </section>

      <section className="dash-grid">
        {/* Requests needing approval */}
        <div className="dash-card">
          <div className="dash-card-header">
            <h3>طلبات تحتاج موافقتك</h3>
          </div>
          {needsApproval.length === 0 ? (
            <p className="dash-empty">لا توجد طلبات جديدة حالياً</p>
          ) : (
            <ul className="dash-request-list">
              {needsApproval.map((r) => (
                <li key={r.id} className="dash-request-item">
                  <div>
                    <p className="dash-request-title">{r.service_name || r.title}</p>
                    <p className="dash-request-sub">{r.location}</p>
                  </div>
                  <div className="dash-request-actions">
                    <button className="dash-btn dash-btn-accept">قبول</button>
                    <button className="dash-btn dash-btn-reject">رفض</button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* In-progress appointments with mini progress bar */}
        <div className="dash-card">
          <div className="dash-card-header">
            <h3>مواعيدك</h3>
          </div>
          {inProgress.length === 0 ? (
            <p className="dash-empty">لا توجد مواعيد حالياً</p>
          ) : (
            <ul className="dash-request-list">
              {inProgress.map((r) => {
                const stepIndex = PROGRESS_STEPS.indexOf(r.progress) ?? 0;
                const pct = ((stepIndex + 1) / PROGRESS_STEPS.length) * 100;
                return (
                  <li key={r.id} className="dash-progress-item">
                    <div className="dash-progress-top">
                      <p className="dash-request-title">{r.service_name || r.title}</p>
                      <span className="dash-progress-label">{r.progress}</span>
                    </div>
                    <div className="dash-progress-track">
                      <div className="dash-progress-fill" style={{ width: `${pct}%` }} />
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </section>

      {/* Building trend line chart */}
      {buildingTrend.length > 0 && (
        <section className="dash-card dash-card-wide">
          <div className="dash-card-header">
            <h3>الطلبات الشهرية حسب المبنى</h3>
          </div>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={buildingTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#eef1f5" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Legend />
              {Object.keys(buildingTrend[0] || {})
                .filter((k) => k !== 'month')
                .map((building, i) => (
                  <Line
                    key={building}
                    type="monotone"
                    dataKey={building}
                    stroke={['#3b82f6', '#f59e0b', '#22c55e', '#a855f7'][i % 4]}
                    strokeWidth={2}
                    dot={false}
                  />
                ))}
            </LineChart>
          </ResponsiveContainer>
        </section>
      )}

      {/* Reviews received */}
      <section className="dash-card dash-card-wide">
        <div className="dash-card-header">
          <h3>التقييمات المستلمة</h3>
        </div>
        {reviews.length === 0 ? (
          <p className="dash-empty">لا توجد تقييمات بعد</p>
        ) : (
          <ul className="dash-review-list">
            {reviews.map((rv) => (
              <li key={rv.id} className="dash-review-item">
                <div>
                  <p className="dash-request-title">{rv.customer_name}</p>
                  <p className="dash-request-sub">{rv.comment}</p>
                </div>
                <span className="dash-review-rating">{'⭐'.repeat(rv.rating)}</span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
