import { useEffect, useState } from 'react';
import {
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip,
  BarChart, Bar, XAxis, YAxis, CartesianGrid,
  LineChart, Line, Legend,
} from 'recharts';
import './AdminDashboardNew.css';

// Adjust this to match your actual API base URL
const API_BASE = 'http://localhost:8000';

const STATUS_COLORS = {
  pending: '#94a3b8',
  accepted: '#3b82f6',
  in_progress: '#f59e0b',
  completed: '#22c55e',
};

const STATUS_LABELS = {
  pending: 'قيد الانتظار',
  accepted: 'مقبولة',
  in_progress: 'قيد التنفيذ',
  completed: 'مكتملة',
};

export default function AdminDashboardNew() {
  const [stats, setStats] = useState(null);
  const [activity, setActivity] = useState([]);
  const [buildingTrend, setBuildingTrend] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    const headers = { Authorization: `Bearer ${token}` };

    Promise.all([
      fetch(`${API_BASE}/admin/stats`, { headers }).then((r) => r.json()),
      fetch(`${API_BASE}/admin/artisans/activity`, { headers }).then((r) => r.json()),
      fetch(`${API_BASE}/artisans/me/monthly-building-stats`, { headers }).then((r) => r.json()).catch(() => []),
    ])
      .then(([statsData, activityData, buildingData]) => {
        setStats(statsData);
        setActivity(activityData);
        setBuildingTrend(buildingData);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="dash-loading">جاري التحميل...</div>;
  if (error) return <div className="dash-error">حدث خطأ: {error}</div>;
  if (!stats) return null;

  const requestsByStatus = Object.entries(stats.requests_by_status || {}).map(
    ([status, count]) => ({
      name: STATUS_LABELS[status] || status,
      value: count,
      color: STATUS_COLORS[status] || '#cbd5e1',
    })
  );

  const totalRequests = requestsByStatus.reduce((sum, s) => sum + s.value, 0);

  const statCards = [
    {
      label: 'إجمالي الحرفيين',
      value: stats.artisans_total,
      sub: `${stats.artisans_verified} موثّق`,
      icon: '🧰',
      accent: '#fef3c7',
    },
    {
      label: 'الحرفيون بانتظار التوثيق',
      value: stats.artisans_pending,
      sub: 'يحتاجون مراجعة',
      icon: '⏳',
      accent: '#fee2e2',
    },
    {
      label: 'العملاء',
      value: stats.customers_count,
      sub: 'مسجلين بالمنصة',
      icon: '👥',
      accent: '#dbeafe',
    },
    {
      label: 'متوسط التقييم',
      value: stats.average_rating?.toFixed(1) ?? '—',
      sub: 'من 5',
      icon: '⭐',
      accent: '#dcfce7',
    },
  ];

  return (
    <div className="dash-wrap" dir="rtl">
      <header className="dash-header">
        <div>
          <p className="dash-greeting">صباح الخير 👋</p>
          <h1 className="dash-title">لوحة تحكم المدير</h1>
          <p className="dash-subtitle">نظرة شاملة على الحرفيين والطلبات والتقييمات</p>
        </div>
      </header>

      {/* Stat Cards */}
      <section className="dash-stats-row">
        {statCards.map((card) => (
          <div className="dash-stat-card" key={card.label}>
            <div className="dash-stat-icon" style={{ background: card.accent }}>
              {card.icon}
            </div>
            <div>
              <p className="dash-stat-label">{card.label}</p>
              <p className="dash-stat-value">{card.value}</p>
              <p className="dash-stat-sub">{card.sub}</p>
            </div>
          </div>
        ))}
      </section>

      <section className="dash-grid">
        {/* Donut chart: requests by status */}
        <div className="dash-card">
          <div className="dash-card-header">
            <h3>الطلبات حسب الحالة</h3>
          </div>
          <div className="dash-donut-row">
            <div className="dash-donut-chart">
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie
                    data={requestsByStatus}
                    dataKey="value"
                    innerRadius={65}
                    outerRadius={95}
                    paddingAngle={2}
                  >
                    {requestsByStatus.map((entry) => (
                      <Cell key={entry.name} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              <div className="dash-donut-center">
                <span className="dash-donut-total">{totalRequests}</span>
                <span className="dash-donut-caption">إجمالي الطلبات</span>
              </div>
            </div>
            <ul className="dash-legend">
              {requestsByStatus.map((s) => (
                <li key={s.name}>
                  <span className="dash-legend-dot" style={{ background: s.color }} />
                  {s.name}
                  <span className="dash-legend-value">
                    {totalRequests ? Math.round((s.value / totalRequests) * 100) : 0}%
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bar chart: artisan activity */}
        <div className="dash-card">
          <div className="dash-card-header">
            <h3>نشاط الحرفيين</h3>
          </div>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={activity}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eef1f5" />
              <XAxis dataKey="artisan_name" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Bar dataKey="today" name="اليوم" fill="#3b82f6" radius={[6, 6, 0, 0]} />
              <Bar dataKey="this_month" name="هذا الشهر" fill="#f59e0b" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      {/* Building trend line chart */}
      {buildingTrend.length > 0 && (
        <section className="dash-card dash-card-wide">
          <div className="dash-card-header">
            <h3>الطلبات الشهرية حسب المبنى</h3>
          </div>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={buildingTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#eef1f5" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Legend />
              {Object.keys(buildingTrend[0] || {})
                .filter((k) => k !== 'month')
                .map((building, i) => (
                  <Line
                    key={building}
                    type="monotone"
                    dataKey={building}
                    stroke={['#3b82f6', '#f59e0b', '#22c55e', '#a855f7'][i % 4]}
                    strokeWidth={2}
                    dot={false}
                  />
                ))}
            </LineChart>
          </ResponsiveContainer>
        </section>
      )}
    </div>
  );
}
